import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function PoliciesModal({ isOpen, onClose, policiesText }) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Policies</DialogTitle>
        </DialogHeader>
        <div className="whitespace-pre-line text-gray-600">
          {policiesText}
        </div>
      </DialogContent>
    </Dialog>
  );
}