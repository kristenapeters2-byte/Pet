import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function HowToPayModal({ isOpen, onClose, howToPayText }) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>How to Pay</DialogTitle>
        </DialogHeader>
        <div className="whitespace-pre-line text-gray-600">
          {howToPayText}
        </div>
      </DialogContent>
    </Dialog>
  );
}