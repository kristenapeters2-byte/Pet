import React, { useState } from "react";
import { Settings } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { X } from "lucide-react";

export default function AvailabilityTab({ settings, onSave }) {
  const [formData, setFormData] = useState(settings);
  const [newBlackoutDate, setNewBlackoutDate] = useState("");

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleWorkDayChange = (day, checked) => {
    const currentDays = formData.workDays || [];
    if (checked) {
      handleChange("workDays", [...currentDays, day]);
    } else {
      handleChange("workDays", currentDays.filter(d => d !== day));
    }
  };

  const handleAddBlackout = () => {
    if (newBlackoutDate && !formData.blackoutDates.includes(newBlackoutDate)) {
      handleChange("blackoutDates", [...formData.blackoutDates, newBlackoutDate]);
      setNewBlackoutDate("");
    }
  };

  const handleRemoveBlackout = (dateToRemove) => {
    handleChange("blackoutDates", formData.blackoutDates.filter(d => d !== dateToRemove));
  };
  
  const handleSave = async () => {
    await onSave(formData);
    alert("Availability settings saved!");
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <h2 className="text-xl font-bold">Availability Settings</h2>
      <div className="space-y-4 p-6 border rounded-lg">
        <div>
          <Label className="text-base font-medium mb-3 block">Work Days</Label>
          <div className="grid grid-cols-4 gap-3">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(day => (
              <div key={day} className="flex items-center space-x-2">
                <Checkbox 
                  id={day}
                  checked={(formData.workDays || []).includes(day)}
                  onCheckedChange={(checked) => handleWorkDayChange(day, checked)}
                />
                <Label htmlFor={day} className="text-sm">{day}</Label>
              </div>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <Label>Start Hour (0-23)</Label>
            <Input type="number" min="0" max="23" value={formData.startHour} onChange={(e) => handleChange("startHour", Number(e.target.value))} />
          </div>
          <div>
            <Label>End Hour (0-23)</Label>
            <Input type="number" min="0" max="23" value={formData.endHour} onChange={(e) => handleChange("endHour", Number(e.target.value))} />
          </div>
          <div>
            <Label>Slot Size (mins)</Label>
            <Input type="number" value={formData.slotSizeMins} onChange={(e) => handleChange("slotSizeMins", Number(e.target.value))} />
          </div>
        </div>
        <div>
          <Label>Blackout Dates</Label>
          <div className="flex gap-2 mb-2">
            <Input type="date" value={newBlackoutDate} onChange={(e) => setNewBlackoutDate(e.target.value)} />
            <Button onClick={handleAddBlackout}>Add Date</Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {formData.blackoutDates.map(date => (
              <div key={date} className="flex items-center gap-1 bg-gray-100 rounded-md px-2 py-1 text-sm">
                {date}
                <button onClick={() => handleRemoveBlackout(date)}><X className="w-3 h-3" /></button>
              </div>
            ))}
          </div>
        </div>
      </div>
      <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700">Save Availability</Button>
    </div>
  );
}