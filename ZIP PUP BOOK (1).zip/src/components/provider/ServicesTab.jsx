import React, { useState, useEffect } from "react";
import { Services } from "@/api/entities";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Edit, Trash, Copy, Link as LinkIcon } from "lucide-react";
import { createPageUrl } from "@/utils";

function ServiceForm({ service, onSave, onCancel }) {
  const [formData, setFormData] = useState(
    service || {
      name: "",
      durationMins: 30,
      displayPriceNote: "",
      description: "",
      showOnHome: true,
      isActive: true,
      minNoticeHours: 12,
      bufferMins: 15,
      maxPerDay: 8,
    }
  );

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    const slug = formData.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    onSave({ ...formData, slug });
  };

  return (
    <div className="space-y-4 max-h-[70vh] overflow-y-auto p-1">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Name</Label>
          <Input value={formData.name} onChange={(e) => handleChange("name", e.target.value)} />
        </div>
        <div>
          <Label>Duration (mins)</Label>
          <Input type="number" value={formData.durationMins} onChange={(e) => handleChange("durationMins", Number(e.target.value))} />
        </div>
      </div>
      <div>
        <Label>Price Note</Label>
        <Input value={formData.displayPriceNote} onChange={(e) => handleChange("displayPriceNote", e.target.value)} placeholder="e.g., from $25" />
      </div>
      <div>
        <Label>Description</Label>
        <Textarea value={formData.description} onChange={(e) => handleChange("description", e.target.value)} />
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label>Min Notice (hrs)</Label>
          <Input type="number" value={formData.minNoticeHours} onChange={(e) => handleChange("minNoticeHours", Number(e.target.value))} />
        </div>
        <div>
          <Label>Buffer (mins)</Label>
          <Input type="number" value={formData.bufferMins} onChange={(e) => handleChange("bufferMins", Number(e.target.value))} />
        </div>
        <div>
          <Label>Max per Day</Label>
          <Input type="number" value={formData.maxPerDay} onChange={(e) => handleChange("maxPerDay", Number(e.target.value))} />
        </div>
      </div>
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <Checkbox id="showOnHome" checked={formData.showOnHome} onCheckedChange={(checked) => handleChange("showOnHome", checked)} />
          <Label htmlFor="showOnHome">Show on Home</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Checkbox id="isActive" checked={formData.isActive} onCheckedChange={(checked) => handleChange("isActive", checked)} />
          <Label htmlFor="isActive">Is Active</Label>
        </div>
      </div>
      <div className="flex justify-end gap-2 pt-4">
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
        <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700">Save Service</Button>
      </div>
    </div>
  );
}

export default function ServicesTab() {
  const [services, setServices] = useState([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingService, setEditingService] = useState(null);

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    const data = await Services.list("-created_date");
    setServices(data);
  };

  const handleSave = async (serviceData) => {
    if (editingService) {
      await Services.update(editingService.id, serviceData);
    } else {
      await Services.create(serviceData);
    }
    await loadServices();
    setIsFormOpen(false);
    setEditingService(null);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this service?")) {
      await Services.delete(id);
      await loadServices();
    }
  };

  const handleEdit = (service) => {
    setEditingService(service);
    setIsFormOpen(true);
  };

  const handleAddNew = () => {
    setEditingService(null);
    setIsFormOpen(true);
  };
  
  const copyLink = (slug) => {
    const url = window.location.origin + createPageUrl(`s/${slug}`);
    navigator.clipboard.writeText(url);
    alert("Link copied to clipboard!");
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Manage Services</h2>
        <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleAddNew} className="bg-green-600 hover:bg-green-700">
              <Plus className="w-4 h-4 mr-2" /> Add New Service
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingService ? "Edit" : "Add"} Service</DialogTitle>
            </DialogHeader>
            <ServiceForm
              service={editingService}
              onSave={handleSave}
              onCancel={() => setIsFormOpen(false)}
            />
          </DialogContent>
        </Dialog>
      </div>
      <div className="border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Active</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {services.map((service) => (
              <TableRow key={service.id}>
                <TableCell>{service.name}</TableCell>
                <TableCell>{service.durationMins} min</TableCell>
                <TableCell>{service.displayPriceNote}</TableCell>
                <TableCell>{service.isActive ? "Yes" : "No"}</TableCell>
                <TableCell className="flex gap-1">
                  <Button variant="ghost" size="icon" onClick={() => copyLink(service.slug)}>
                    <LinkIcon className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleEdit(service)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(service.id)}>
                    <Trash className="w-4 h-4 text-red-500" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}