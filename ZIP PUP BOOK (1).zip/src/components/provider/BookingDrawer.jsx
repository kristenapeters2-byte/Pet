import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import ChatThread from '../chat/ChatThread';
import { format } from 'date-fns';

export default function BookingDrawer({ 
  booking, 
  service, 
  isOpen, 
  onClose, 
  onStatusChange 
}) {
  if (!booking || !service) return null;

  const getStatusColor = (status) => {
    switch (status) {
      case "Pending": return "bg-yellow-100 text-yellow-800";
      case "Confirmed": return "bg-green-100 text-green-800";
      case "Declined": case "Canceled": return "bg-red-100 text-red-800";
      case "Completed": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Booking #{booking.code}</DialogTitle>
          <DialogDescription>
            {service.name} for {booking.clientName}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="p-4 border rounded-lg">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h4 className="font-semibold">Booking Details</h4>
                <p className="text-sm text-gray-600">
                  {format(new Date(booking.startAt), 'MMM d, yyyy @ h:mm a')}
                </p>
              </div>
              <Badge className={getStatusColor(booking.status)}>{booking.status}</Badge>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <p><span className="font-medium">Client:</span> {booking.clientName}</p>
              <p><span className="font-medium">Phone:</span> {booking.clientPhone}</p>
              <p><span className="font-medium">Address:</span> {booking.address}</p>
              <p><span className="font-medium">Dogs:</span> {booking.dogs}</p>
              {booking.petNotes && <p className="col-span-2"><span className="font-medium">Notes:</span> {booking.petNotes}</p>}
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-2">Chat</h4>
            <ChatThread bookingId={booking.id} userType="provider" />
          </div>
          
          <div className="flex flex-wrap gap-2 justify-end pt-4">
            {booking.status === "Pending" && (
              <>
                <Button 
                  onClick={() => onStatusChange(booking.id, "Confirmed")}
                  className="bg-green-600 hover:bg-green-700"
                >
                  Confirm
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => onStatusChange(booking.id, "Declined")}
                >
                  Decline
                </Button>
              </>
            )}
            {booking.status === "Confirmed" && (
              <Button 
                onClick={() => onStatusChange(booking.id, "Completed")}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Mark as Completed
              </Button>
            )}
            {["Pending", "Confirmed"].includes(booking.status) && (
               <Button 
                  variant="destructive"
                  onClick={() => onStatusChange(booking.id, "Canceled")}
                >
                  Cancel Booking
                </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}