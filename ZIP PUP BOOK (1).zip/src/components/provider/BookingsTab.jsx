import React, { useState, useEffect } from "react";
import { Bookings, Services } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Eye } from "lucide-react";
import { format } from "date-fns";
import BookingDrawer from "./BookingDrawer";

export default function BookingsTab() {
  const [bookings, setBookings] = useState([]);
  const [services, setServices] = useState([]);
  const [filter, setFilter] = useState("pending");
  const [selectedBooking, setSelectedBooking] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [bookingsData, servicesData] = await Promise.all([
      Bookings.list("-created_date"),
      Services.list()
    ]);
    setBookings(bookingsData);
    setServices(servicesData);
  };

  const handleStatusChange = async (bookingId, newStatus) => {
    await Bookings.update(bookingId, { status: newStatus });
    await loadData();
    // Keep drawer open if it's not a final state
    if (["Completed", "Canceled", "Declined"].includes(newStatus)) {
      setSelectedBooking(null);
    } else {
       const updatedBooking = await Bookings.get(bookingId);
       setSelectedBooking(updatedBooking);
    }
  };

  const filteredBookings = bookings.filter(booking => {
    if (filter === "all") return true;
    if (filter === "pending") return booking.status === "Pending";
    if (filter === "upcoming") return ["Pending", "Confirmed"].includes(booking.status) && new Date(booking.startAt) >= new Date();
    if (filter === "completed") return booking.status === "Completed";
    return true;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case "Pending": return "bg-yellow-100 text-yellow-800";
      case "Confirmed": return "bg-green-100 text-green-800";
      case "Declined": case "Canceled": return "bg-red-100 text-red-800";
      case "Completed": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div>
      <div className="flex gap-2 mb-6">
        {["pending", "upcoming", "completed", "all"].map(f => (
          <Button 
            key={f}
            variant={filter === f ? "default" : "outline"}
            onClick={() => setFilter(f)}
            className={filter === f ? "bg-green-600 hover:bg-green-700" : ""}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </Button>
        ))}
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredBookings.map((booking) => {
          const service = services.find(s => s.id === booking.serviceId);
          return (
            <Card key={booking.id} className="cursor-pointer hover:shadow-md" onClick={() => setSelectedBooking(booking)}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-lg">{service?.name}</h3>
                    <p className="text-sm text-gray-500">{booking.clientName}</p>
                  </div>
                  <Badge className={getStatusColor(booking.status)}>
                    {booking.status}
                  </Badge>
                </div>
                
                <p className="text-sm text-gray-800 mb-4">
                  {format(new Date(booking.startAt), 'EEE, MMM d @ h:mm a')}
                </p>

                <Button variant="outline" size="sm" className="w-full">
                  <Eye className="w-4 h-4 mr-2" /> View Details & Chat
                </Button>
              </CardContent>
            </Card>
          );
        })}
        {filteredBookings.length === 0 && (
          <p className="text-gray-500 md:col-span-3 text-center py-8">No {filter} bookings.</p>
        )}
      </div>
      
      <BookingDrawer
        booking={selectedBooking}
        service={selectedBooking ? services.find(s => s.id === selectedBooking.serviceId) : null}
        isOpen={!!selectedBooking}
        onClose={() => setSelectedBooking(null)}
        onStatusChange={handleStatusChange}
      />
    </div>
  );
}