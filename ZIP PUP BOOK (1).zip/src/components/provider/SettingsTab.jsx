import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { X } from "lucide-react";

export default function SettingsTab({ settings, onSave }) {
  const [formData, setFormData] = useState(settings);

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleJsonChange = (field, subField, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: {
        ...prev[field],
        [subField]: value,
      }
    }));
  };
  
  const handleFaqChange = (index, key, value) => {
    const newFaq = [...formData.faq];
    newFaq[index][key] = value;
    handleChange('faq', newFaq);
  };
  
  const addFaq = () => {
    handleChange('faq', [...formData.faq, { q: '', a: '' }]);
  };
  
  const removeFaq = (index) => {
    handleChange('faq', formData.faq.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    await onSave(formData);
    alert("Settings saved!");
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <h2 className="text-xl font-bold">Branding & Settings</h2>
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Business Info</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Business Name</Label>
              <Input value={formData.businessName} onChange={(e) => handleChange("businessName", e.target.value)} />
            </div>
            <div>
              <Label>Logo URL</Label>
              <Input value={formData.logoUrl} onChange={(e) => handleChange("logoUrl", e.target.value)} />
            </div>
            <div>
              <Label>Theme Color</Label>
              <Input type="color" value={formData.themeColor} onChange={(e) => handleChange("themeColor", e.target.value)} />
            </div>
             <div>
              <Label>About Text</Label>
              <Textarea value={formData.aboutText} onChange={(e) => handleChange("aboutText", e.target.value)} />
            </div>
             <div>
              <Label>Service Areas</Label>
              <Input value={formData.serviceAreas} onChange={(e) => handleChange("serviceAreas", e.target.value)} />
            </div>
             <div>
              <Label>Provider PIN</Label>
              <Input type="password" value={formData.providerPIN} onChange={(e) => handleChange("providerPIN", e.target.value)} />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader><CardTitle>Client-Facing Text</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Policies</Label>
              <Textarea rows={4} value={formData.policiesText} onChange={(e) => handleChange("policiesText", e.target.value)} />
            </div>
            <div>
              <Label>How to Pay</Label>
              <Textarea rows={4} value={formData.howToPayText} onChange={(e) => handleChange("howToPayText", e.target.value)} />
            </div>
          </CardContent>
        </Card>
        
        <Card className="md:col-span-2">
          <CardHeader><CardTitle>FAQ</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {formData.faq.map((item, index) => (
              <div key={index} className="flex gap-2 items-start">
                <div className="flex-1 grid gap-2">
                  <Input placeholder="Question" value={item.q} onChange={e => handleFaqChange(index, 'q', e.target.value)} />
                  <Textarea placeholder="Answer" value={item.a} onChange={e => handleFaqChange(index, 'a', e.target.value)} />
                </div>
                <Button variant="ghost" size="icon" onClick={() => removeFaq(index)}><X className="w-4 h-4"/></Button>
              </div>
            ))}
            <Button variant="outline" onClick={addFaq}>Add FAQ Item</Button>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader><CardTitle>Socials</CardTitle></CardHeader>
          <CardContent className="space-y-4">
             <div>
              <Label>Website URL</Label>
              <Input value={formData.socials.website} onChange={(e) => handleJsonChange("socials", "website", e.target.value)} />
            </div>
             <div>
              <Label>Instagram Handle</Label>
              <Input value={formData.socials.instagram} onChange={(e) => handleJsonChange("socials", "instagram", e.target.value)} />
            </div>
          </CardContent>
        </Card>
      </div>
      <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700">Save All Settings</Button>
    </div>
  );
}