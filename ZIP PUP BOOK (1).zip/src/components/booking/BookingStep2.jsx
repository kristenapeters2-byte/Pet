import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export default function BookingStep2({ 
  formData,
  setFormData,
  onNext,
  onBack
}) {
  const handleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const canProceed = formData.clientName && 
                    formData.clientPhone && 
                    formData.address && 
                    formData.dogs >= 1;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Your details</h2>
        <p className="text-gray-600">Tell us about you and your pup(s)</p>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="clientName">Your Name *</Label>
            <Input
              id="clientName"
              value={formData.clientName}
              onChange={(e) => handleChange('clientName', e.target.value)}
              placeholder="John Doe"
            />
          </div>
          
          <div>
            <Label htmlFor="clientPhone">Phone Number *</Label>
            <Input
              id="clientPhone"
              type="tel"
              value={formData.clientPhone}
              onChange={(e) => handleChange('clientPhone', e.target.value)}
              placeholder="(555) 123-4567"
            />
          </div>
        </div>

        <div>
          <Label htmlFor="address">Service Address *</Label>
          <Textarea
            id="address"
            value={formData.address}
            onChange={(e) => handleChange('address', e.target.value)}
            placeholder="123 Main St, Atlanta, GA 30309"
            rows={2}
          />
        </div>

        <div>
          <Label htmlFor="dogs">Number of Dogs *</Label>
          <Input
            id="dogs"
            type="number"
            min="1"
            value={formData.dogs}
            onChange={(e) => handleChange('dogs', parseInt(e.target.value) || 1)}
            placeholder="1"
          />
        </div>

        <div>
          <Label htmlFor="petNotes">Pet Care Notes (optional)</Label>
          <Textarea
            id="petNotes"
            value={formData.petNotes}
            onChange={(e) => handleChange('petNotes', e.target.value)}
            placeholder="Any special instructions, allergies, or behavioral notes..."
            rows={3}
          />
        </div>
      </div>

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack}>
          Back
        </Button>
        <Button 
          onClick={onNext}
          disabled={!canProceed}
          className="bg-green-600 hover:bg-green-700"
        >
          Review & Confirm
        </Button>
      </div>
    </div>
  );
}