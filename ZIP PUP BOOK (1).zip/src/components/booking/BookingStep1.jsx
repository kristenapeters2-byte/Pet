import React, { useState, useEffect, useCallback } from "react";
import { Services, Bookings } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import { Clock } from "lucide-react";
import { format, addHours, isAfter } from "date-fns";

export default function BookingStep1({ 
  selectedServiceId, 
  setSelectedServiceId,
  selectedDate,
  setSelectedDate,
  selectedTime,
  setSelectedTime,
  settings,
  onNext
}) {
  const [services, setServices] = useState([]);
  const [availableSlots, setAvailableSlots] = useState([]);
  const [loading, setLoading] = useState(false);

  const loadServices = useCallback(async () => {
    const data = await Services.filter({ isActive: true });
    setServices(data);
  }, []);

  const loadAvailableSlots = useCallback(async () => {
    if (!selectedDate || !selectedServiceId || !settings) return;
    
    setLoading(true);
    
    try {
      // Get existing confirmed bookings for the date
      const dateStr = format(selectedDate, 'yyyy-MM-dd');
      const bookings = await Bookings.list();
      const dayBookings = bookings.filter(b => 
        b.status === 'Confirmed' && 
        format(new Date(b.startAt), 'yyyy-MM-dd') === dateStr
      );
      
      // Generate time slots
      const slots = makeSlots(dateStr, settings.startHour, settings.endHour, settings.slotSizeMins);
      const selectedService = services.find(s => s.id === selectedServiceId);
      
      if (!selectedService) {
        setAvailableSlots([]);
        setLoading(false);
        return;
      }

      // Filter out unavailable slots
      const now = new Date();
      const minNoticeTime = addHours(now, selectedService.minNoticeHours || 0);
      
      const availableSlots = slots.filter(slot => {
        // Check minimum notice
        if (!isAfter(slot, minNoticeTime)) return false;
        
        // Check overlaps with existing bookings
        const slotRange = paddedRange(slot, selectedService.durationMins, selectedService.bufferMins || 0);
        
        return !dayBookings.some(booking => {
          const bookingService = services.find(s => s.id === booking.serviceId);
          if (!bookingService) return false;
          
          const bookingRange = paddedRange(
            new Date(booking.startAt), 
            bookingService.durationMins, 
            bookingService.bufferMins || 0
          );
          
          return overlaps(slotRange.start, slotRange.end, bookingRange.start, bookingRange.end);
        });
      });
      
      setAvailableSlots(availableSlots);
    } catch (error) {
      console.error('Error loading slots:', error);
      setAvailableSlots([]);
    } finally {
      setLoading(false);
    }
  }, [selectedDate, selectedServiceId, settings, services]);

  useEffect(() => {
    loadServices();
  }, [loadServices]);

  useEffect(() => {
    loadAvailableSlots();
  }, [loadAvailableSlots]);

  const makeSlots = (dateISO, startHour, endHour, slotMins) => {
    const start = new Date(dateISO);
    start.setHours(startHour, 0, 0, 0);
    const end = new Date(dateISO);
    end.setHours(endHour, 0, 0, 0);
    
    const slots = [];
    for (let t = new Date(start); t < end; t = new Date(t.getTime() + slotMins * 60000)) {
      slots.push(new Date(t));
    }
    return slots;
  };

  const paddedRange = (start, durationMins, bufferMins) => {
    const s = new Date(start);
    const e = new Date(s.getTime() + durationMins * 60000);
    return {
      start: new Date(s.getTime() - (bufferMins || 0) * 60000),
      end: new Date(e.getTime() + (bufferMins || 0) * 60000)
    };
  };

  const overlaps = (aStart, aEnd, bStart, bEnd) => {
    return aStart < bEnd && bStart < aEnd;
  };

  const isDateDisabled = (date) => {
    if (!settings) return true;
    
    const dateStr = format(date, 'yyyy-MM-dd');
    if (settings.blackoutDates && settings.blackoutDates.includes(dateStr)) return true;
    
    const dayName = format(date, 'EEE');
    return !settings.workDays || !settings.workDays.includes(dayName);
  };

  const selectedService = services.find(s => s.id === selectedServiceId);
  const canProceed = selectedServiceId && selectedDate && selectedTime;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Pick a service and time</h2>
        <p className="text-gray-600">Choose what you need and when you need it</p>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Service
          </label>
          <Select value={selectedServiceId} onValueChange={setSelectedServiceId}>
            <SelectTrigger>
              <SelectValue placeholder="Select a service" />
            </SelectTrigger>
            <SelectContent>
              {services.map((service) => (
                <SelectItem key={service.id} value={service.id}>
                  {service.name} ({service.durationMins} min) - {service.displayPriceNote}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          {selectedService && (
            <div className="mt-2 p-3 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600">{selectedService.description}</p>
              <Badge variant="outline" className="mt-2">
                {selectedService.displayPriceNote}
              </Badge>
            </div>
          )}
        </div>

        {selectedServiceId && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Date
            </label>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={setSelectedDate}
              disabled={isDateDisabled}
              className="rounded-md border"
            />
          </div>
        )}

        {selectedDate && selectedServiceId && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Time
            </label>
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto"></div>
                <p className="text-sm text-gray-500 mt-2">Loading available times...</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {availableSlots.map((slot) => (
                  <Button
                    key={slot.toISOString()}
                    variant={selectedTime?.getTime() === slot.getTime() ? "default" : "outline"}
                    onClick={() => setSelectedTime(slot)}
                    className="flex items-center gap-2"
                  >
                    <Clock className="w-4 h-4" />
                    {format(slot, 'h:mm a')}
                  </Button>
                ))}
                {availableSlots.length === 0 && (
                  <div className="col-span-full text-center py-4 text-gray-500">
                    No available time slots for this date
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      <div className="flex justify-end">
        <Button 
          onClick={onNext}
          disabled={!canProceed}
          className="bg-green-600 hover:bg-green-700"
        >
          Next: Your Details
        </Button>
      </div>
    </div>
  );
}