
import React, { useState, useEffect, useCallback } from "react";
import { Bookings, Services } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin, Dog, User, Phone } from "lucide-react";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function BookingStep3({ 
  selectedServiceId,
  selectedDate,
  selectedTime,
  formData,
  onBack,
  clientId
}) {
  const [isCreating, setIsCreating] = useState(false);
  const [selectedService, setSelectedService] = useState(null);
  const navigate = useNavigate();

  const loadService = useCallback(async () => {
    if (selectedServiceId) {
      const service = await Services.get(selectedServiceId);
      setSelectedService(service);
    }
  }, [selectedServiceId]);

  useEffect(() => {
    loadService();
  }, [loadService]);

  const generateCode = () => {
    return Math.floor(100000 + Math.random() * 900000).toString();
  };

  const createBooking = async () => {
    setIsCreating(true);
    
    const code = generateCode();
    
    await Bookings.create({
      code,
      status: "Pending",
      serviceId: selectedServiceId,
      startAt: selectedTime.toISOString(),
      dogs: formData.dogs,
      clientName: formData.clientName,
      clientPhone: formData.clientPhone,
      address: formData.address,
      petNotes: formData.petNotes,
      clientId: clientId,
    });

    const cid = localStorage.getItem('clientId');
    if (cid) {
      // Returning client → goes to their dashboard
      navigate(createPageUrl('my'));
    } else {
      // One-time guest → goes to login page with success message
      navigate(createPageUrl('client-login'));
    }
  };

  if (!selectedService) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Review & confirm</h2>
        <p className="text-gray-600">Double-check your booking details</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Dog className="w-5 h-5 text-green-600" />
            Booking Summary
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3">
            <Clock className="w-4 h-4 text-gray-400" />
            <span className="font-medium">{selectedService.name}</span>
            <Badge variant="outline">{selectedService.durationMins} min</Badge>
          </div>
          
          <div className="flex items-center gap-3">
            <Calendar className="w-4 h-4 text-gray-400" />
            <span>{format(selectedDate, 'EEEE, MMMM do, yyyy')}</span>
          </div>
          
          <div className="flex items-center gap-3">
            <Clock className="w-4 h-4 text-gray-400" />
            <span>{format(selectedTime, 'h:mm a')}</span>
          </div>

          <div className="flex items-center gap-3">
            <User className="w-4 h-4 text-gray-400" />
            <span>{formData.clientName}</span>
          </div>

          <div className="flex items-center gap-3">
            <Phone className="w-4 h-4 text-gray-400" />
            <span>{formData.clientPhone}</span>
          </div>

          <div className="flex items-start gap-3">
            <MapPin className="w-4 h-4 text-gray-400 mt-1" />
            <span className="text-sm">{formData.address}</span>
          </div>

          <div className="flex items-center gap-3">
            <Dog className="w-4 h-4 text-gray-400" />
            <span>{formData.dogs} dog{formData.dogs !== 1 ? 's' : ''}</span>
          </div>

          {formData.petNotes && (
            <div className="bg-gray-50 p-3 rounded-lg">
              <p className="text-sm font-medium text-gray-700">Pet Notes:</p>
              <p className="text-sm text-gray-600 mt-1">{formData.petNotes}</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <span className="text-lg font-medium">Price:</span>
            <Badge variant="secondary" className="text-lg">
              {selectedService.displayPriceNote}
            </Badge>
          </div>
          <p className="text-sm text-gray-500 mt-2">
            Payment is handled outside the app. Instructions will be provided after confirmation.
          </p>
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack}>
          Back
        </Button>
        <Button 
          onClick={createBooking}
          disabled={isCreating}
          className="bg-green-600 hover:bg-green-700"
        >
          {isCreating ? "Creating..." : "Create Booking"}
        </Button>
      </div>
    </div>
  );
}
