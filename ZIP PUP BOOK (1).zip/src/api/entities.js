import { base44 } from './base44Client';


export const Settings = base44.entities.Settings;

export const Services = base44.entities.Services;

export const Bookings = base44.entities.Bookings;

export const Messages = base44.entities.Messages;

export const Testimonials = base44.entities.Testimonials;

export const Clients = base44.entities.Clients;



// auth sdk:
export const User = base44.auth;