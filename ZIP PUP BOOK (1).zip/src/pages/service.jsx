
import React, { useState, useEffect } from "react";
import { Services, Settings } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Clock, Calendar } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import HowToPayModal from "../components/modals/HowToPayModal";
import PoliciesModal from "../components/modals/PoliciesModal";

export default function Service() {
  const [service, setService] = useState(null);
  const [settings, setSettings] = useState(null);
  const [showHowToPay, setShowHowToPay] = useState(false);
  const [showPolicies, setShowPolicies] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const slug = urlParams.get('slug');
    
    if (!slug) {
      // If no slug, redirect to home
      window.location.href = createPageUrl("Home");
      return;
    }
    
    const [servicesData, settingsData] = await Promise.all([
      Services.filter({ slug }),
      Settings.list()
    ]);
    
    if (servicesData.length > 0) {
      setService(servicesData[0]);
    } else {
      // If service not found, redirect to home
      window.location.href = createPageUrl("Home");
      return;
    }
    
    if (settingsData.length > 0) {
      setSettings(settingsData[0]);
    }
  };

  if (!service || !settings) {
    return <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
    </div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Home")}>
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            {settings.logoUrl && (
              <img 
                src={settings.logoUrl} 
                alt={settings.businessName}
                className="h-10 w-10 rounded-lg object-cover"
              />
            )}
            <h1 className="text-2xl font-bold text-gray-900">
              {settings.businessName}
            </h1>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Service Details */}
        <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:gap-4 mb-4">
            <h1 className="text-3xl font-bold text-gray-900">{service.name}</h1>
            <Badge variant="outline" className="flex items-center gap-1 w-fit mt-2 sm:mt-0">
              <Clock className="w-3 h-3" />
              {service.durationMins} min
            </Badge>
          </div>
          
          <p className="text-xl text-green-600 font-semibold mb-6">
            {service.displayPriceNote}
          </p>
          
          <div className="prose max-w-none text-gray-700">
             {service.description}
          </div>

          <div className="flex flex-col sm:flex-row gap-4 mt-8">
            <Link to={createPageUrl(`book?serviceId=${service.id}`)}>
              <Button size="lg" className="w-full sm:w-auto bg-green-600 hover:bg-green-700">
                <Calendar className="w-5 h-5 mr-2" />
                Book This Service
              </Button>
            </Link>
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => setShowHowToPay(true)}
              className="w-full sm:w-auto"
            >
              How to Pay
            </Button>
          </div>
        </div>

        {/* FAQ Section */}
        {settings.faq && settings.faq.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Frequently Asked Questions
            </h2>
            <div className="space-y-4">
              {settings.faq.map((item, index) => (
                <div key={index} className="border-b border-gray-200 pb-4 last:border-b-0">
                  <h3 className="font-semibold text-gray-900 mb-2">{item.q}</h3>
                  <p className="text-gray-600">{item.a}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="text-center space-y-4">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="font-semibold text-gray-900 mb-2">Service Areas</h3>
            <p className="text-gray-600">{settings.serviceAreas}</p>
          </div>
          
          <div className="flex justify-center gap-6 text-sm">
            <button 
              onClick={() => setShowPolicies(true)}
              className="text-green-600 hover:underline"
            >
              Policies
            </button>
            <button 
              onClick={() => setShowHowToPay(true)}
              className="text-green-600 hover:underline"
            >
              How to Pay
            </button>
          </div>
        </div>
      </div>

      <HowToPayModal 
        isOpen={showHowToPay}
        onClose={() => setShowHowToPay(false)}
        howToPayText={settings.howToPayText}
      />
      
      <PoliciesModal 
        isOpen={showPolicies}
        onClose={() => setShowPolicies(false)}
        policiesText={settings.policiesText}
      />
    </div>
  );
}
