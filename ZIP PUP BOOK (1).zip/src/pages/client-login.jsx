import React, { useState } from 'react';
import { Clients } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useNavigate, Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowLeft } from 'lucide-react';

export default function ClientLogin() {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const trimmedPin = String(pin || '').trim();
    if (!/^\d{6}$/.test(trimmedPin)) {
      setError('Please enter a valid 6-digit PIN.');
      setLoading(false);
      return;
    }

    try {
        const clients = await Clients.filter({ pin: trimmedPin });
        const client = clients[0];

        if (client) {
            localStorage.setItem('clientId', client.id);
            navigate(createPageUrl('my'));
        } else {
            setError('Incorrect PIN.');
        }
    } catch (err) {
        setError('An error occurred. Please try again.');
        console.error(err);
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white p-4 flex items-center justify-center">
      <Card className="w-full max-w-sm">
        <CardHeader>
           <Link to={createPageUrl("Home")} className="absolute left-4 top-4">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
          <CardTitle className="text-center pt-8">Client Portal</CardTitle>
          <CardDescription className="text-center">Enter your 6-digit PIN to access your dashboard.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="pin">6-Digit PIN</Label>
              <Input id="pin" type="password" value={pin} onChange={(e) => setPin(e.target.value)} required maxLength={6} />
            </div>

            {error && <p className="text-sm text-red-600">{error}</p>}

            <Button type="submit" className="w-full bg-green-600 hover:bg-green-700" disabled={loading}>
              {loading ? 'Logging In...' : 'Log In'}
            </Button>
          </form>
          
          <div className="mt-6 p-4 bg-blue-50 rounded-lg text-center">
            <p className="text-sm text-blue-800">
              <strong>Don't have a PIN?</strong><br/>
              Your PIN is provided by your service provider. 
              Contact them to get access.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}