
import React, { useState, useEffect, useCallback } from "react";
import { Bookings, Services, Settings } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Calendar, Clock, MapPin, Dog, User, Phone } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import ChatThread from "../components/chat/ChatThread";
import HowToPayModal from "../components/modals/HowToPayModal";
import PoliciesModal from "../components/modals/PoliciesModal";

export default function Client() {
  const [code, setCode] = useState("");
  const [lastName, setLastName] = useState("");
  const [currentBooking, setCurrentBooking] = useState(null);
  const [service, setService] = useState(null);
  const [settings, setSettings] = useState(null);
  const [showHowToPay, setShowHowToPay] = useState(false);
  const [showPolicies, setShowPolicies] = useState(false);
  const [error, setError] = useState("");

  // Define functions for global access, using useCallback for stability
  const refreshSessionUI = useCallback(() => {
    const hasClient = !!localStorage.getItem('clientId');
    const hasProvider = localStorage.getItem('isProviderAuthed') === '1';

    const clientStatus = document.getElementById('clientStatus');
    const providerStatus = document.getElementById('providerStatus');
    if (clientStatus) clientStatus.style.display = hasClient ? '' : 'none';
    if (providerStatus) providerStatus.style.display = hasProvider ? '' : 'none';

    const goMyBtn = document.getElementById('goMyBtn');
    const goProviderBtn = document.getElementById('goProviderBtn');
    if (goMyBtn) goMyBtn.style.display = hasClient ? '' : 'none';
    if (goProviderBtn) goProviderBtn.style.display = hasProvider ? '' : 'none';

    const clientLogoutBtn = document.getElementById('clientLogoutBtn');
    const providerLogoutBtn = document.getElementById('providerLogoutBtn');
    if (clientLogoutBtn) clientLogoutBtn.style.display = hasClient ? '' : 'none';
    if (providerLogoutBtn) providerLogoutBtn.style.display = hasProvider ? '' : 'none';

    const footerProviderLink = document.getElementById('footerProviderLoginLink');
    if (footerProviderLink) footerProviderLink.style.display = hasProvider ? 'none' : '';
  }, []); // No dependencies as it only interacts with DOM and localStorage

  const clientLogout = useCallback(() => {
    localStorage.removeItem('clientId');
    refreshSessionUI(); // Call the component's refreshSessionUI
    if (location.pathname === '/my') window.location.replace('/client-login');
    else if (location.pathname === '/') window.location.reload();
  }, [refreshSessionUI]); // Depends on refreshSessionUI

  const providerLogout = useCallback(() => {
    localStorage.removeItem('isProviderAuthed');
    refreshSessionUI(); // Call the component's refreshSessionUI
    if (location.pathname === '/provider') {
      window.location.replace('/provider-login');
    } else {
      window.location.reload();
    }
  }, [refreshSessionUI]); // Depends on refreshSessionUI

  useEffect(() => {
    loadSettings();
    
    // Check for code in URL
    const urlParams = new URLSearchParams(window.location.search);
    const urlCode = urlParams.get('code');
    if (urlCode) {
      setCode(urlCode);
    }

    // Attach these functions to the window object for global access
    window.refreshSessionUI = refreshSessionUI;
    window.clientLogout = clientLogout;
    window.providerLogout = providerLogout;

    // Initial refresh of the UI immediately when component mounts
    refreshSessionUI();

    // Add DOMContentLoaded listener to ensure UI refresh even if DOM content loads later
    document.addEventListener('DOMContentLoaded', window.refreshSessionUI);

    // Cleanup function
    return () => {
      document.removeEventListener('DOMContentLoaded', window.refreshSessionUI);
      // It's good practice to clean up window attachments if this component
      // might be unmounted and remounted, to avoid memory leaks or
      // unexpected behavior if other components also define these globals.
      // However, for app-wide global utilities like these, they often remain
      // on the window object throughout the application's lifecycle.
      // delete window.refreshSessionUI;
      // delete window.clientLogout;
      // delete window.providerLogout;
    };
  }, [refreshSessionUI, clientLogout, providerLogout]); // Dependencies to ensure useEffect uses the latest function instances

  const loadSettings = async () => {
    const settingsData = await Settings.list();
    if (settingsData.length > 0) {
      setSettings(settingsData[0]);
    }
  };

  const openPortal = async () => {
    setError("");
    
    if (!code || !lastName) {
      setError("Please enter both booking code and last name/phone");
      return;
    }

    try {
      const bookings = await Bookings.filter({ code });
      
      if (bookings.length === 0) {
        setError("Booking not found");
        return;
      }

      const booking = bookings[0];
      const searchTerm = lastName.toLowerCase();
      const nameMatch = booking.clientName.toLowerCase().includes(searchTerm);
      const phoneMatch = booking.clientPhone.toLowerCase().includes(searchTerm);

      if (!nameMatch && !phoneMatch) {
        setError("Last name or phone doesn't match our records");
        return;
      }

      setCurrentBooking(booking);
      
      // Load service details
      const serviceData = await Services.get(booking.serviceId);
      setService(serviceData);
      
    } catch (err) {
      setError("Error accessing booking");
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "Pending": return "bg-gray-100 text-gray-800";
      case "Confirmed": return "bg-green-100 text-green-800";
      case "Declined": case "Canceled": return "bg-red-100 text-red-800";
      case "Completed": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  if (!settings) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* Session status bar */}
      <div id="sessionBar" style={{display:'flex', gap:'12px', alignItems:'center', justifyContent:'flex-end', fontSize:'14px', padding:'6px 12px', backgroundColor:'#f9fafb', borderBottom:'1px solid #e5e7eb'}}>
        <span id="clientStatus" style={{display:'none', padding:'4px 8px', border:'1px solid #e0e0e0', borderRadius:'999px', backgroundColor:'#dcfce7', color:'#166534'}}>Client: logged in</span>
        <span id="providerStatus" style={{display:'none', padding:'4px 8px', border:'1px solid #e0e0e0', borderRadius:'999px', backgroundColor:'#dbeafe', color:'#1e40af'}}>Provider: logged in</span>

        <button id="goMyBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #d1d5db', borderRadius:'4px', backgroundColor:'white', cursor:'pointer'}} onClick={() => window.location.href='/my'}>My Bookings</button>
        <button id="goProviderBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #d1d5db', borderRadius:'4px', backgroundColor:'white', cursor:'pointer'}} onClick={() => window.location.href='/provider'}>Dashboard</button>

        <button id="clientLogoutBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #ef4444', borderRadius:'4px', backgroundColor:'#fef2f2', color:'#dc2626', cursor:'pointer'}} onClick={() => window.clientLogout()}>Logout (Client)</button>
        <button id="providerLogoutBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #ef4444', borderRadius:'4px', backgroundColor:'#fef2f2', color:'#dc2626', cursor:'pointer'}} onClick={() => window.providerLogout()}>Logout (Provider)</button>
      </div>

      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Home")}>
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-gray-900">Client Portal</h1>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8">
        {!currentBooking ? (
          /* Gate Card */
          <Card>
            <CardHeader>
              <CardTitle>Access Your Booking</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Booking Code
                </label>
                <Input
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="6-digit code"
                  maxLength={6}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Last Name or Phone
                </label>
                <Input
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="For verification"
                />
              </div>

              {error && (
                <p className="text-sm text-red-600">{error}</p>
              )}

              <Button 
                onClick={openPortal}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                Open Portal
              </Button>
            </CardContent>
          </Card>
        ) : (
          /* Booking Details */
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Booking Details</CardTitle>
                  <Badge className={getStatusColor(currentBooking.status)}>
                    {currentBooking.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {service && (
                  <div className="flex items-center gap-3">
                    <Clock className="w-4 h-4 text-gray-400" />
                    <span className="font-medium">{service.name}</span>
                    <Badge variant="outline">{service.durationMins} min</Badge>
                  </div>
                )}
                
                <div className="flex items-center gap-3">
                  <Calendar className="w-4 h-4 text-gray-400" />
                  <span>{format(new Date(currentBooking.startAt), 'EEEE, MMMM do, yyyy')}</span>
                </div>
                
                <div className="flex items-center gap-3">
                  <Clock className="w-4 h-4 text-gray-400" />
                  <span>{format(new Date(currentBooking.startAt), 'h:mm a')}</span>
                </div>

                <div className="flex items-center gap-3">
                  <Dog className="w-4 h-4 text-gray-400" />
                  <span>{currentBooking.dogs} dog{currentBooking.dogs !== 1 ? 's' : ''}</span>
                </div>

                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-gray-400 mt-1" />
                  <span className="text-sm">{currentBooking.address}</span>
                </div>

                {currentBooking.petNotes && (
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm font-medium text-gray-700">Pet Notes:</p>
                    <p className="text-sm text-gray-600 mt-1">{currentBooking.petNotes}</p>
                  </div>
                )}

                <div className="flex gap-2 pt-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setShowHowToPay(true)}
                  >
                    How to Pay
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setShowPolicies(true)}
                  >
                    Policies
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Chat */}
            <Card>
              <CardHeader>
                <CardTitle>Chat with Provider</CardTitle>
                <p className="text-sm text-gray-600">
                  This chat stays inside the app.
                </p>
              </CardHeader>
              <CardContent>
                <ChatThread 
                  bookingId={currentBooking.id} 
                  userType="client" 
                />
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      <HowToPayModal 
        isOpen={showHowToPay}
        onClose={() => setShowHowToPay(false)}
        howToPayText={settings.howToPayText}
      />
      
      <PoliciesModal 
        isOpen={showPolicies}
        onClose={() => setShowPolicies(false)}
        policiesText={settings.policiesText}
      />
    </div>
  );
}
