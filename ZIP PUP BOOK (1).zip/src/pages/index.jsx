import Layout from "./Layout.jsx";

import book from "./book";

import client from "./client";

import provider from "./provider";

import service from "./service";

import Home from "./Home";

import Root from "./Root";

import my from "./my";

import client-login from "./client-login";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    book: book,
    
    client: client,
    
    provider: provider,
    
    service: service,
    
    Home: Home,
    
    Root: Root,
    
    my: my,
    
    client-login: client-login,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<book />} />
                
                
                <Route path="/book" element={<book />} />
                
                <Route path="/client" element={<client />} />
                
                <Route path="/provider" element={<provider />} />
                
                <Route path="/service" element={<service />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Root" element={<Root />} />
                
                <Route path="/my" element={<my />} />
                
                <Route path="/client-login" element={<client-login />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}