
import React, { useState, useEffect, useCallback } from 'react';
import { Clients, Bookings, Services } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LogOut, Calendar, Clock, Dog, Settings as SettingsIcon } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { format } from 'date-fns';

export default function MyDashboard() {
  const [client, setClient] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [services, setServices] = useState({});
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const clientId = localStorage.getItem('clientId');

  // Check session protection
  useEffect(() => {
    if (!localStorage.getItem('clientId')) {
      window.location.replace('/client-login');
      return;
    }
  }, []);

  // Attach logout functions to window for global access
  useEffect(() => {
    window.clientLogout = function() {
      localStorage.removeItem('clientId');
      if (window.refreshSessionUI) window.refreshSessionUI();
      if (location.pathname === '/my') window.location.replace('/client-login');
    };

    window.providerLogout = function() {
      localStorage.removeItem('isProviderAuthed');
      if (window.refreshSessionUI) window.refreshSessionUI();
      if (location.pathname === '/provider') {
        location.reload();
      }
    };
  }, []);

  const loadData = useCallback(async () => {
    if (!clientId) {
      navigate(createPageUrl('client-login'), { replace: true });
      return;
    }
    
    setLoading(true);
    try {
      const [clientData, bookingsData, servicesData] = await Promise.all([
        Clients.get(clientId),
        Bookings.filter({ clientId: clientId }, '-startAt'),
        Services.list()
      ]);

      setClient(clientData);
      setBookings(bookingsData);
      
      const servicesMap = servicesData.reduce((acc, service) => {
        acc[service.id] = service;
        return acc;
      }, {});
      setServices(servicesMap);
      
    } catch (error) {
      console.error("Failed to load dashboard data", error);
      // If client not found, maybe local storage is stale.
      localStorage.removeItem('clientId');
      navigate(createPageUrl('client-login'), { replace: true });
    } finally {
      setLoading(false);
    }
  }, [clientId, navigate]);

  useEffect(() => {
    loadData();
  }, [loadData]);
  
  // This handleLogout is for the main 'Log Out' button on the dashboard, navigating to the Home page.
  const handleLogout = () => {
    localStorage.removeItem('clientId');
    navigate(createPageUrl('Home'));
  };

  if (loading || !client) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
      </div>
    );
  }
  
  const now = new Date();
  const upcomingBookings = bookings.filter(b => new Date(b.startAt) >= now && b.status !== 'Canceled' && b.status !== 'Declined' && b.status !== 'Completed');
  const pastBookings = bookings.filter(b => new Date(b.startAt) < now || b.status === 'Completed' || b.status === 'Canceled' || b.status === 'Declined');

  const getStatusColor = (status) => {
    switch (status) {
      case "Pending": return "bg-gray-100 text-gray-800";
      case "Confirmed": return "bg-green-100 text-green-800";
      case "Declined": case "Canceled": return "bg-red-100 text-red-800";
      case "Completed": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white p-4 sm:p-8">
      {/* Session status bar */}
      <div id="sessionBar" style={{display:'flex', gap:'12px', alignItems:'center', justifyContent:'flex-end', fontSize:'14px', padding:'6px 12px', backgroundColor:'#f9fafb', borderBottom:'1px solid #e5e7eb', margin:'-16px -32px 16px -32px'}}>
        <span id="clientStatus" style={{display:'none', padding:'4px 8px', border:'1px solid #e0e0e0', borderRadius:'999px', backgroundColor:'#dcfce7', color:'#166534'}}>Client: logged in</span>
        <span id="providerStatus" style={{display:'none', padding:'4px 8px', border:'1px solid #e0e0e0', borderRadius:'999px', backgroundColor:'#dbeafe', color:'#1e40af'}}>Provider: logged in</span>

        <button id="goMyBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #d1d5db', borderRadius:'4px', backgroundColor:'white', cursor:'pointer'}} onClick={() => window.location.href='/my'}>My Bookings</button>
        <button id="goProviderBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #d1d5db', borderRadius:'4px', backgroundColor:'white', cursor:'pointer'}} onClick={() => window.location.href='/provider'}>Dashboard</button>

        <button id="clientLogoutBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #ef4444', borderRadius:'4px', backgroundColor:'#fef2f2', color:'#dc2626', cursor:'pointer'}} onClick={() => window.clientLogout()}>Logout (Client)</button>
        <button id="providerLogoutBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #ef4444', borderRadius:'4px', backgroundColor:'#fef2f2', color:'#dc2626', cursor:'pointer'}} onClick={() => window.providerLogout()}>Logout (Provider)</button>
      </div>

      <div className="max-w-4xl mx-auto">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Welcome, {client.name.split(' ')[0]}!</h1>
            <p className="text-gray-600">Your personal dog care dashboard.</p>
          </div>
          <Button variant="ghost" onClick={handleLogout} className="flex items-center gap-2">
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Log Out</span>
          </Button>
        </header>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="md:col-span-3">
                <CardHeader><CardTitle>Actions</CardTitle></CardHeader>
                <CardContent className="flex flex-col gap-3">
                     <Link to={createPageUrl(`book?clientId=${clientId}`)} className="w-full">
                        <Button className="w-full bg-green-600 hover:bg-green-700">Book Another Service</Button>
                    </Link>
                </CardContent>
            </Card>
        </div>
        
        <section>
          <h2 className="text-2xl font-bold mb-4">Upcoming Bookings</h2>
          {upcomingBookings.length > 0 ? (
            <div className="space-y-4">
              {upcomingBookings.map(booking => (
                <Card key={booking.id}>
                  <CardContent className="p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                      <h3 className="font-semibold text-lg">{services[booking.serviceId]?.name || 'Service'}</h3>
                      <div className="flex items-center gap-3 text-sm text-gray-600 mt-1">
                          <span className="flex items-center gap-1"><Calendar className="w-4 h-4"/> {format(new Date(booking.startAt), 'EEE, MMM d')}</span>
                          <span className="flex items-center gap-1"><Clock className="w-4 h-4"/> {format(new Date(booking.startAt), 'h:mm a')}</span>
                      </div>
                    </div>
                     <div className="flex items-center gap-4">
                        <Badge className={getStatusColor(booking.status)}>{booking.status}</Badge>
                        <Link to={createPageUrl(`client?code=${booking.code}&lastName=${client.name.split(' ').pop()}`)}>
                            <Button variant="outline" size="sm">View & Chat</Button>
                        </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-4 bg-gray-50 rounded-lg">No upcoming bookings.</p>
          )}
        </section>

         <section className="mt-12">
          <h2 className="text-2xl font-bold mb-4">Past Bookings</h2>
          {pastBookings.length > 0 ? (
            <div className="space-y-4">
              {pastBookings.map(booking => (
                 <Card key={booking.id} className="opacity-70">
                   <CardContent className="p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                      <h3 className="font-semibold">{services[booking.serviceId]?.name || 'Service'}</h3>
                      <p className="text-sm text-gray-500">{format(new Date(booking.startAt), 'MMM d, yyyy')}</p>
                    </div>
                    <Badge className={getStatusColor(booking.status)}>{booking.status}</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
             <p className="text-gray-500 text-center py-4 bg-gray-50 rounded-lg">No past bookings yet.</p>
          )}
        </section>
      </div>

      <script dangerouslySetInnerHTML={{__html: `
function refreshSessionUI(){
  const hasClient = !!localStorage.getItem('clientId');
  const hasProvider = localStorage.getItem('isProviderAuthed') === '1';

  const clientStatus = document.getElementById('clientStatus');
  const providerStatus = document.getElementById('providerStatus');
  if (clientStatus) clientStatus.style.display = hasClient ? '' : 'none';
  if (providerStatus) providerStatus.style.display = hasProvider ? '' : 'none';

  const goMyBtn = document.getElementById('goMyBtn');
  const goProviderBtn = document.getElementById('goProviderBtn');
  if (goMyBtn) goMyBtn.style.display = hasClient ? '' : 'none';
  if (goProviderBtn) goProviderBtn.style.display = hasProvider ? '' : 'none';

  const clientLogoutBtn = document.getElementById('clientLogoutBtn');
  const providerLogoutBtn = document.getElementById('providerLogoutBtn');
  if (clientLogoutBtn) clientLogoutBtn.style.display = hasClient ? '' : 'none';
  if (providerLogoutBtn) providerLogoutBtn.style.display = hasProvider ? '' : 'none';

  const footerProviderLink = document.getElementById('footerProviderLoginLink');
  if (footerProviderLink) footerProviderLink.style.display = hasProvider ? 'none' : '';
}

window.refreshSessionUI = refreshSessionUI;

document.addEventListener('DOMContentLoaded', refreshSessionUI);
      `}} />
    </div>
  );
}
