
import React, { useState, useEffect } from "react";
import { Services, Settings, Testimonials } from "@/api/entities";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, MapPin, Star } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import HowToPayModal from "../components/modals/HowToPayModal";
import PoliciesModal from "../components/modals/PoliciesModal";

export default function Home() {
  const [services, setServices] = useState([]);
  const [settings, setSettings] = useState(null);
  const [testimonials, setTestimonials] = useState([]);
  const [showHowToPay, setShowHowToPay] = useState(false);
  const [showPolicies, setShowPolicies] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  // Attach clientLogout function to window for global access
  React.useEffect(() => {
    window.clientLogout = function() {
      localStorage.removeItem('clientId');
      // refreshSessionUI is removed, no longer needed here
      if (window.updateClientPortalLink) window.updateClientPortalLink(); // Update the client portal link on logout
      if (location.pathname === '/my') window.location.replace('/client-login');
    };
    // window.providerLogout is removed as its logic is now inline in the button
  }, []); // Run once on mount

  const loadData = async () => {
    const [servicesData, settingsData, testimonialsData] = await Promise.all([
      Services.filter({ showOnHome: true, isActive: true }),
      Settings.list(),
      Testimonials.list("-date", 3)
    ]);
    
    setServices(servicesData);
    if (settingsData.length > 0) {
      setSettings(settingsData[0]);
    }
    setTestimonials(testimonialsData);
  };

  if (!settings) {
    return <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
    </div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* Provider session status + quick controls */}
      <div id="providerBar" style={{display:'flex', gap:'8px', justifyContent:'flex-end', fontSize:'14px', padding:'6px 12px', backgroundColor:'#f9fafb', borderBottom:'1px solid #e5e7eb'}}>
        <span id="provChip" style={{display:'none', padding:'4px 8px', border:'1px solid #e0e0e0', borderRadius:'999px', backgroundColor:'#dbeafe', color:'#1e40af'}}>
          Provider: logged in
        </span>
        <button id="provDashBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #d1d5db', borderRadius:'4px', backgroundColor:'white', cursor:'pointer'}} onClick={() => window.location.href='/provider'}>
          Dashboard
        </button>
        <button id="provLogoutBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #ef4444', borderRadius:'4px', backgroundColor:'#fef2f2', color:'#dc2626', cursor:'pointer'}} onClick={() => {localStorage.removeItem('isProviderAuthed'); window.location.reload();}}>
          Logout
        </button>
      </div>

      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center gap-4 mb-6">
            {settings.logoUrl && (
              <img 
                src={settings.logoUrl} 
                alt={settings.businessName}
                className="h-12 w-12 rounded-lg object-cover"
              />
            )}
            <div>
              <h1 className="text-3xl font-bold text-gray-900">{settings.businessName}</h1>
              <p className="text-lg text-gray-600 mt-2">Direct dog care—simple, local, trusted.</p>
            </div>
          </div>
          
          <div className="text-center max-w-3xl mx-auto">
            <p className="text-xl text-gray-700 mb-8">
              {settings.aboutText || "Book walks and sits, chat in-app, and follow clear payment instructions."}
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={createPageUrl("book")}>
                <Button size="lg" className="w-full sm:w-auto bg-green-600 hover:bg-green-700">
                  Request a One-Time Service
                </Button>
              </Link>
              <a
                id="clientPortalLink"
                href={createPageUrl('client-login')}
                className={buttonVariants({ variant: "outline", size: "lg", className: "w-full sm:w-auto" })}
              >
                Returning Client: Client Portal
              </a>
            </div>
            
            <div className="grid sm:grid-cols-2 gap-4 mt-6 text-sm text-gray-600 max-w-2xl mx-auto">
              <div>
                <p><strong>New here?</strong> Use this to request a walk or visit without an account.</p>
              </div>
              <div>
                <p><strong>Already a client?</strong> Log in with the 6-digit PIN we gave you.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Services */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Our Services</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => (
              <Card key={service.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">{service.name}</CardTitle>
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {service.durationMins} min
                    </Badge>
                  </div>
                  <p className="text-lg font-semibold text-green-600">
                    {service.displayPriceNote}
                  </p>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-6">{service.description}</p>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Link to={createPageUrl(`service?slug=${service.slug}`)} className="flex-1">
                      <Button variant="outline" className="w-full">
                        View Details
                      </Button>
                    </Link>
                    <Link to={createPageUrl(`book?serviceId=${service.id}`)} className="flex-1">
                      <Button className="w-full bg-green-600 hover:bg-green-700">
                        Book Now
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Service Areas */}
        <div className="text-center mb-16">
          <div className="bg-white rounded-lg shadow-sm p-8">
            <div className="flex items-center justify-center gap-2 mb-4">
              <MapPin className="w-6 h-6 text-green-600" />
              <h2 className="text-2xl font-bold text-gray-900">Service Areas</h2>
            </div>
            <p className="text-xl text-gray-700">{settings.serviceAreas}</p>
          </div>
        </div>

        {/* Testimonials */}
        {testimonials.length > 0 && (
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
              What Our Clients Say
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <Card key={index} className="bg-white">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-1 mb-4">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <p className="text-gray-600 mb-4 italic">"{testimonial.quote}"</p>
                    <p className="font-semibold text-gray-900">
                      {testimonial.clientName} & {testimonial.petName}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="bg-white border-t border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-gray-600">© 2025 {settings.businessName}. All rights reserved.</p>
            <div className="flex gap-6">
              <button 
                onClick={() => setShowPolicies(true)}
                className="text-green-600 hover:underline"
              >
                Policies
              </button>
              <button 
                onClick={() => setShowHowToPay(true)}
                className="text-green-600 hover:underline"
              >
                How to Pay
              </button>
              <Link 
                to={createPageUrl("provider")}
                id="footerProviderLoginLink"
                className="text-sm text-gray-400 hover:text-gray-600 transition-colors"
              >
                Provider Login
              </Link>
            </div>
          </div>
        </div>
      </div>

      <HowToPayModal 
        isOpen={showHowToPay}
        onClose={() => setShowHowToPay(false)}
        howToPayText={settings.howToPayText}
      />
      
      <PoliciesModal 
        isOpen={showPolicies}
        onClose={() => setShowPolicies(false)}
        policiesText={settings.policiesText}
      />

      <script dangerouslySetInnerHTML={{__html: `
// ---- Utilities ----
window.pb = window.pb || {};
pb.digitsOnly = (s)=> String(s||'').replace(/\\D/g,'');
pb.nowISO     = ()=> new Date().toISOString();

// Provider session management
function refreshProviderUI() {
  const authed = localStorage.getItem('isProviderAuthed') === '1';
  const show = (id, on) => { 
    const el = document.getElementById(id); 
    if (el) el.style.display = on ? '' : 'none'; 
  };
  
  show('provChip', authed);
  show('provDashBtn', authed);
  show('provLogoutBtn', authed);

  // Hide footer Provider Login link when already authed
  const footerProvLink = document.getElementById('footerProviderLoginLink');
  if (footerProvLink) footerProvLink.style.display = authed ? 'none' : '';
}

function updateClientPortalLink() {
  try {
    const cid = localStorage.getItem('clientId');
    if (cid) {
      const link = document.getElementById('clientPortalLink');
      if (link) link.href = '/my';
    }
  } catch (e) {
    // Ignore; fallback href still works
  }
}

function onDomReady() {
  refreshProviderUI();
  updateClientPortalLink();
}

// Make functions globally accessible
window.refreshProviderUI = refreshProviderUI;
window.updateClientPortalLink = updateClientPortalLink; // Expose to global scope for clientLogout to call it

// Initialize UI on page load
document.addEventListener('DOMContentLoaded', onDomReady);
      `}} />
    </div>
  );
}
