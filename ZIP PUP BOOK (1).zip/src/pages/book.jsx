
import React, { useState, useEffect } from "react";
import { Settings, Clients } from "@/api/entities";
import BookingStep1 from "../components/booking/BookingStep1";
import BookingStep2 from "../components/booking/BookingStep2";
import BookingStep3 from "../components/booking/BookingStep3";
import HowToPayModal from "../components/modals/HowToPayModal";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Book() {
  const [currentStep, setCurrentStep] = useState(1);
  const [settings, setSettings] = useState(null);
  const [showHowToPay, setShowHowToPay] = useState(false);
  const [clientId, setClientId] = useState(null);
  
  // Step 1 data
  const [selectedServiceId, setSelectedServiceId] = useState("");
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  
  // Step 2 data
  const [formData, setFormData] = useState({
    clientName: "",
    clientPhone: "",
    address: "",
    dogs: 1,
    petNotes: ""
  });

  useEffect(() => {
    // Attach client logout function to window for global access
    window.clientLogout = function() {
      localStorage.removeItem('clientId');
      setClientId(null); // Update React state
      // refreshSessionUI is removed, no call needed here.
      if (location.pathname === '/my') window.location.replace('/client-login');
    };

    const urlParams = new URLSearchParams(window.location.search);
    const serviceId = urlParams.get('serviceId');
    if (serviceId) {
      setSelectedServiceId(serviceId);
    }
    
    const cid = urlParams.get('clientId') || localStorage.getItem('clientId');
    if (cid) {
        setClientId(cid);
    }

    loadInitialData(cid);
  }, []);

  const loadInitialData = async (cid) => {
    const settingsData = await Settings.list();
    if (settingsData.length > 0) {
      setSettings(settingsData[0]);
    }
    if (cid) {
        try {
            const client = await Clients.get(cid);
            if (client) {
                setFormData(prev => ({
                    ...prev,
                    clientName: client.name,
                    clientPhone: client.phone, // We can format this later
                    address: client.addressDefault,
                }));
            }
        } catch (e) {
            console.error("Could not load client, maybe they logged out.", e);
            localStorage.removeItem('clientId');
            setClientId(null);
        }
    }
  };

  const nextStep = () => {
    setCurrentStep(prev => prev + 1);
  };

  const prevStep = () => {
    setCurrentStep(prev => prev - 1);
  };

  if (!settings) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* Provider session status + quick controls */}
      <div id="providerBar" style={{display:'flex', gap:'8px', justifyContent:'flex-end', fontSize:'14px', padding:'6px 12px', backgroundColor:'#f9fafb', borderBottom:'1px solid #e5e7eb'}}>
        <span id="provChip" style={{display:'none', padding:'4px 8px', border:'1px solid #e0e0e0', borderRadius:'999px', backgroundColor:'#dbeafe', color:'#1e40af'}}>
          Provider: logged in
        </span>
        <button id="provDashBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #d1d5db', borderRadius:'4px', backgroundColor:'white', cursor:'pointer'}} onClick={() => window.location.href='/provider'}>
          Dashboard
        </button>
        <button id="provLogoutBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #ef4444', borderRadius:'4px', backgroundColor:'#fef2f2', color:'#dc2626', cursor:'pointer'}} onClick={() => {localStorage.removeItem('isProviderAuthed'); window.location.reload();}}>
          Logout
        </button>
      </div>

      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Home")}>
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Book Service</h1>
              <div className="flex items-center gap-2 mt-1">
                {[1, 2, 3].map((step) => (
                  <div
                    key={step}
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      step === currentStep
                        ? "bg-green-600 text-white"
                        : step < currentStep
                        ? "bg-green-100 text-green-600"
                        : "bg-gray-100 text-gray-400"
                    }`}
                  >
                    {step}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8">
        {currentStep === 1 && (
          <BookingStep1
            selectedServiceId={selectedServiceId}
            setSelectedServiceId={setSelectedServiceId}
            selectedDate={selectedDate}
            setSelectedDate={setSelectedDate}
            selectedTime={selectedTime}
            setSelectedTime={setSelectedTime}
            settings={settings}
            onNext={nextStep}
          />
        )}

        {currentStep === 2 && (
          <BookingStep2
            formData={formData}
            setFormData={setFormData}
            onNext={nextStep}
            onBack={prevStep}
          />
        )}

        {currentStep === 3 && (
          <BookingStep3
            selectedServiceId={selectedServiceId}
            selectedDate={selectedDate}
            selectedTime={selectedTime}
            formData={formData}
            onBack={prevStep}
            clientId={clientId}
          />
        )}

        {/* Footer */}
        <div className="mt-12 text-center">
          <button 
            onClick={() => setShowHowToPay(true)}
            className="text-sm text-green-600 hover:underline"
          >
            How to pay
          </button>
        </div>
      </div>

      <HowToPayModal 
        isOpen={showHowToPay}
        onClose={() => setShowHowToPay(false)}
        howToPayText={settings.howToPayText}
      />
      
      <script dangerouslySetInnerHTML={{__html: `
function refreshProviderUI() {
  const authed = localStorage.getItem('isProviderAuthed') === '1';
  const show = (id, on) => { 
    const el = document.getElementById(id); 
    if (el) el.style.display = on ? '' : 'none'; 
  };
  
  show('provChip', authed);
  show('provDashBtn', authed);
  show('provLogoutBtn', authed);
}

window.refreshProviderUI = refreshProviderUI;

document.addEventListener('DOMContentLoaded', refreshProviderUI);
      `}} />
    </div>
  );
}
