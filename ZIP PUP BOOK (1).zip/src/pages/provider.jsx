import React, { useEffect, useState } from "react";
import { Settings } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ServicesTab from "../components/provider/ServicesTab";
import AvailabilityTab from "../components/provider/AvailabilityTab";
import SettingsTab from "../components/provider/SettingsTab";
import BookingsTab from "../components/provider/BookingsTab";

/**
 * ProviderPage
 * - Gate provider dashboard behind Settings.providerPIN
 * - Persist session in localStorage ("isProviderAuthed" === "1")
 */
export default function Provider() {
  // State for settings data
  const [settings, setSettings] = useState(null);
  const [settingsLoading, setSettingsLoading] = useState(true);
  
  // Authentication state
  const [authed, setAuthed] = useState(false);
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [checking, setChecking] = useState(true);

  // Load settings on mount
  useEffect(() => {
    const loadSettings = async () => {
      try {
        const settingsData = await Settings.list();
        if (settingsData.length > 0) {
          setSettings(settingsData[0]);
        }
      } catch (err) {
        console.error('Failed to load settings:', err);
      } finally {
        setSettingsLoading(false);
      }
    };
    loadSettings();
  }, []);

  // Restore session from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem("isProviderAuthed") === "1";
      setAuthed(saved);
      // Update global UI when component mounts
      if (window.refreshProviderUI) {
        window.refreshProviderUI();
      }
    } catch (_) {
      // no-op
    } finally {
      setChecking(false);
    }
  }, []);

  // Get provider PIN from settings
  const providerPIN = (settings && settings.providerPIN && String(settings.providerPIN)) || "123";

  // Submit handler
  const handleLogin = (e) => {
    e?.preventDefault?.();
    setError("");

    const entered = String(pin || "").trim();

    if (!entered) {
      setError("Enter your provider PIN.");
      return;
    }

    if (entered === providerPIN) {
      try {
        localStorage.setItem("isProviderAuthed", "1");
        // Update global UI after successful login
        if (window.refreshProviderUI) {
          window.refreshProviderUI();
        }
      } catch (_) {}
      setAuthed(true);
      setPin("");
    } else {
      setError("Incorrect PIN. Try again.");
    }
  };

  // Logout handler
  const handleLogout = () => {
    try {
      localStorage.removeItem("isProviderAuthed");
      // Update global UI after logout
      if (window.refreshProviderUI) {
        window.refreshProviderUI();
      }
    } catch (_) {}
    setAuthed(false);
    setPin("");
  };

  // Settings save handler for tabs
  const handleSettingsSave = async (updatedSettings) => {
    if (!settings) return;
    await Settings.update(settings.id, updatedSettings);
    // Reload settings
    const settingsData = await Settings.list();
    if (settingsData.length > 0) {
      setSettings(settingsData[0]);
    }
  };

  if (checking || settingsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* Provider session status + quick controls */}
      <div id="providerBar" style={{display:'flex', gap:'8px', justifyContent:'flex-end', fontSize:'14px', padding:'6px 12px', backgroundColor:'#f9fafb', borderBottom:'1px solid #e5e7eb'}}>
        <span id="provChip" style={{display:'none', padding:'4px 8px', border:'1px solid #e0e0e0', borderRadius:'999px', backgroundColor:'#dbeafe', color:'#1e40af'}}>
          Provider: logged in
        </span>
        <button id="provDashBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #d1d5db', borderRadius:'4px', backgroundColor:'white', cursor:'pointer'}} onClick={() => window.location.href='/provider'}>
          Dashboard
        </button>
        <button id="provLogoutBtn" style={{display:'none', padding:'4px 8px', border:'1px solid #ef4444', borderRadius:'4px', backgroundColor:'#fef2f2', color:'#dc2626', cursor:'pointer'}} onClick={handleLogout}>
          Logout
        </button>
      </div>

      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Home")}>
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-gray-900">Provider Dashboard</h1>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {!authed ? (
          // PIN Gate
          <section id="provPinGate">
            <div className="max-w-md mx-auto">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Provider Login</h2>
                
                {!settings?.providerPIN && (
                  <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 p-3 rounded-lg mb-4">
                    <p className="text-sm">
                      <strong>Heads up:</strong> No Settings provider PIN found. Using fallback <strong>123</strong>.
                      Update <em>Data → Settings → providerPIN</em>.
                    </p>
                  </div>
                )}

                <form onSubmit={handleLogin} className="space-y-4">
                  <input
                    type="password"
                    inputMode="numeric"
                    placeholder="Enter provider PIN"
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    maxLength="6"
                  />
                  
                  {error && (
                    <div className="text-red-600 text-sm">{error}</div>
                  )}
                  
                  <button
                    type="submit"
                    className="w-full px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg transition-colors"
                  >
                    Login
                  </button>
                </form>
              </div>
            </div>
          </section>
        ) : (
          // Dashboard
          <section id="provDashboard">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Provider Dashboard</h2>
              <div className="flex items-center gap-3">
                <span className="px-3 py-1 text-sm bg-blue-100 text-blue-800 rounded-full border">
                  Provider: logged in
                </span>
                <Button 
                  onClick={handleLogout}
                  variant="outline"
                  size="sm"
                >
                  Logout
                </Button>
              </div>
            </div>

            <Tabs defaultValue="bookings" className="w-full">
              <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 mb-8">
                <TabsTrigger value="bookings">Bookings</TabsTrigger>
                <TabsTrigger value="services">Services</TabsTrigger>
                <TabsTrigger value="availability">Availability</TabsTrigger>
                <TabsTrigger value="settings">Branding & Settings</TabsTrigger>
              </TabsList>

              <TabsContent value="bookings">
                <BookingsTab />
              </TabsContent>

              <TabsContent value="services">
                <ServicesTab />
              </TabsContent>

              <TabsContent value="availability">
                {settings && (
                  <AvailabilityTab settings={settings} onSave={handleSettingsSave} />
                )}
              </TabsContent>

              <TabsContent value="settings">
                {settings && (
                  <SettingsTab settings={settings} onSave={handleSettingsSave} />
                )}
              </TabsContent>
            </Tabs>
          </section>
        )}
      </div>

      <script dangerouslySetInnerHTML={{__html: `
// Global UI refresh function for provider status bar
function refreshProviderUI() {
  const authed = localStorage.getItem('isProviderAuthed') === '1';
  const show = (id, on) => { 
    const el = document.getElementById(id); 
    if (el) el.style.display = on ? '' : 'none'; 
  };
  
  show('provChip', authed);
  show('provDashBtn', authed);
  show('provLogoutBtn', authed);

  // Hide footer Provider Login link when already authed
  const footerProvLink = document.getElementById('footerProviderLoginLink');
  if (footerProvLink) footerProvLink.style.display = authed ? 'none' : '';
}

// Make function globally accessible
window.refreshProviderUI = refreshProviderUI;

// Initialize on page load
document.addEventListener('DOMContentLoaded', refreshProviderUI);
      `}} />
    </div>
  );
}